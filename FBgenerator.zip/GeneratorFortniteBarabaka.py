# language: Python, file: gcfortnite_final.py, target: Desktop/PyQt6
import sys
import os
import random
import string
import webbrowser
import math
from PyQt6.QtWidgets import (QApplication, QMainWindow, QWidget, QVBoxLayout, 
                             QLabel, QPushButton, QHBoxLayout, QFileDialog, 
                             QMessageBox, QSpinBox, QGraphicsDropShadowEffect, QStackedWidget, QFrame)
from PyQt6.QtCore import Qt, QPoint, QThread, pyqtSignal, QTimer, QRectF
from PyQt6.QtGui import QFont, QCursor, QColor, QPainter, QPainterPath, QPen

TRANSLATIONS = {
    'ru': {
        'title': 'GCFORTNITE | BARABAKA',
        'count': 'Количество кодов:',
        'unlim': 'Снять лимит',
        'folder': 'Выбрать папку',
        'folder_lbl': 'Папка: {}',
        'ready': 'Готов к работе',
        'start': 'СТАРТ ГЕНЕРАЦИИ',
        'stop': 'ОСТАНОВИТЬ ГЕНЕРАЦИЮ',
        'generating': 'Генерация запущена...',
        'generated_prog': 'Сгенерировано: {} кодов...',
        'generated_done': 'Сгенерировано: {}\nСохранено в: {}',
        'help_title': 'ИНФОРМАЦИЯ',
        'help_text': 'Скрипт сделан на палке с помощью gemini но вродь работает,\nзанимается ток генерацией, кто шарит допишите сами автоматизацию,\nзащиты от взлома кода там нету и обфусикации тож,\nмой дс: nonininino1212w321',
        'epic': 'Epic Games GCR'
    },
    'en': {
        'title': 'GCFORTNITE | BARABAKA',
        'count': 'Amount of codes:',
        'unlim': 'Remove limit',
        'folder': 'Select Folder',
        'folder_lbl': 'Folder: {}',
        'ready': 'Ready to work',
        'start': 'START GENERATION',
        'stop': 'STOP GENERATION',
        'generating': 'Generation started...',
        'generated_prog': 'Generated: {} codes...',
        'generated_done': 'Generated: {}\nSaved to: {}',
        'help_title': 'INFORMATION',
        'help_text': 'The script was put together on the fly with Gemini but seems to work,\nit only does generation. Those who know how can add automation themselves,\nthere is no anti-tamper protection or obfuscation either.\nMy ds: nonininino1212w321',
        'epic': 'Epic Games GCR'
    }
}

class WaveFrame(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.phase = 0.0
        self.timer = QTimer(self)
        self.timer.timeout.connect(self.update_animation)
        self.timer.start(30)

    def update_animation(self):
        self.phase += 0.03
        self.update()

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.RenderHint.Antialiasing)
        w, h = self.width(), self.height()
        rect = QRectF(0, 0, w, h)

        path_bg = QPainterPath()
        path_bg.addRoundedRect(rect, 15, 15)
        painter.setClipPath(path_bg)
        painter.fillPath(path_bg, QColor(0, 0, 0))

        self.draw_wave(painter, w, h, y_base=h*0.7, amp=25, freq=0.015, phase_shift=self.phase, color=QColor(20, 20, 20, 150))
        self.draw_wave(painter, w, h, y_base=h*0.5, amp=40, freq=0.010, phase_shift=-self.phase * 1.5, color=QColor(35, 35, 35, 150))
        self.draw_wave(painter, w, h, y_base=h*0.3, amp=30, freq=0.008, phase_shift=self.phase * 0.8, color=QColor(50, 50, 50, 100))
        self.draw_wave(painter, w, h, y_base=h*0.8, amp=60, freq=0.005, phase_shift=-self.phase * 0.5, color=QColor(15, 15, 15, 200))

        painter.setClipping(False) 
        painter.setPen(QPen(QColor(255, 255, 255), 3)) 
        painter.setBrush(Qt.BrushStyle.NoBrush)
        painter.drawRoundedRect(1, 1, w-2, h-2, 15, 15)

    def draw_wave(self, painter, w, h, y_base, amp, freq, phase_shift, color):
        path = QPainterPath()
        path.moveTo(0, h)
        step = 5
        for x in range(0, int(w) + step, step):
            y = y_base + math.sin(x * freq + phase_shift) * amp
            path.lineTo(x, y)
        path.lineTo(w, h)
        path.closeSubpath()
        painter.fillPath(path, color)


class GeneratorThread(QThread):
    progress = pyqtSignal(int)
    finished = pyqtSignal(str, str) 

    def __init__(self, count, folder):
        super().__init__()
        self.count = count
        self.folder = folder
        self.is_running = True

    def run(self):
        chars = string.ascii_uppercase + string.digits
        filepath = os.path.join(self.folder, "GCFORTNITE_codes.txt")
        codes = set()
        generated = 0

        try:
            with open(filepath, "w", encoding="utf-8") as f:
                while self.is_running:
                    # Жесткое ограничение - стоп ровно на заданном числе
                    if generated >= self.count:
                        break
                    
                    p1 = ''.join(random.choices(chars, k=4))
                    p2 = ''.join(random.choices(chars, k=4))
                    p3 = ''.join(random.choices(chars, k=4))
                    p4 = ''.join(random.choices(chars, k=4))
                    code = f"{p1}-{p2}-{p3}-{p4}"

                    if code not in codes:
                        codes.add(code)
                        f.write(code + "\n")
                        generated += 1

                        if generated % 100 == 0:
                            self.progress.emit(generated)

            self.finished.emit(str(generated), filepath)
        except Exception as e:
            self.finished.emit("0", f"Ошибка: {e}")


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowFlags(Qt.WindowType.FramelessWindowHint)
        self.setAttribute(Qt.WidgetAttribute.WA_TranslucentBackground)
        self.setFixedSize(500, 420)
        
        self.save_folder = os.path.join(os.path.expanduser("~"), "Desktop")
        self.generator_thread = None
        self.lang = 'ru'
        
        self.old_pos = None
        self.init_ui()

    def bw_btn_style(self, radius=10, font_size=12, checkable=False):
        checked_css = "QPushButton:checked { background: white; color: black; }" if checkable else ""
        return f"""
            QPushButton {{
                background: black;
                color: white;
                border: 2px solid white;
                border-radius: {radius}px;
                font-size: {font_size}px;
                font-weight: bold;
            }}
            QPushButton:hover {{ background: #1a1a1a; }}
            QPushButton:pressed {{
                background: #333333;
                margin-top: 3px; 
                margin-bottom: -3px;
            }}
            {checked_css}
        """

    def init_ui(self):
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        main_layout = QVBoxLayout(central_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        
        self.main_frame = WaveFrame()
        
        shadow = QGraphicsDropShadowEffect()
        shadow.setBlurRadius(20)
        shadow.setColor(QColor(0, 0, 0, 180))
        shadow.setOffset(0, 8)
        self.main_frame.setGraphicsEffect(shadow)
        
        frame_layout = QVBoxLayout(self.main_frame)
        frame_layout.setContentsMargins(0, 0, 0, 0)
        
        self.stack = QStackedWidget()
        self.stack.setStyleSheet("background: transparent;")
        
        self.init_lang_screen()
        frame_layout.addWidget(self.stack)
        main_layout.addWidget(self.main_frame)

    def init_lang_screen(self):
        self.page_lang = QWidget()
        lang_layout = QVBoxLayout(self.page_lang)
        lang_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        lbl_layout = QHBoxLayout()
        for text in ["russia", "english"]:
            lbl = QLabel(text)
            lbl.setFont(QFont("Segoe UI", 9))
            lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            lbl.setStyleSheet("border: none; color: white; background: transparent;")
            lbl_layout.addWidget(lbl)
            
        lang_layout.addLayout(lbl_layout)

        flags_layout = QHBoxLayout()
        flags_layout.setSpacing(20)
        
        btn_ru = QPushButton("🇷🇺")
        btn_ru.setFixedSize(120, 90)
        btn_ru.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_ru.setStyleSheet(self.bw_btn_style(radius=15, font_size=40))
        btn_ru.clicked.connect(lambda: self.set_language('ru'))
        
        btn_en = QPushButton("🇺🇸")
        btn_en.setFixedSize(120, 90)
        btn_en.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_en.setStyleSheet(self.bw_btn_style(radius=15, font_size=40))
        btn_en.clicked.connect(lambda: self.set_language('en'))
        
        flags_layout.addWidget(btn_ru)
        flags_layout.addWidget(btn_en)
        lang_layout.addLayout(flags_layout)
        
        self.stack.addWidget(self.page_lang)

    def set_language(self, lang_code):
        self.lang = lang_code
        self.init_main_app_screen()
        self.stack.setCurrentIndex(1)

    def init_main_app_screen(self):
        self.page_main = QWidget()
        layout = QVBoxLayout(self.page_main)
        layout.setContentsMargins(25, 20, 25, 20)
        
        T = TRANSLATIONS[self.lang]
        
        header_layout = QHBoxLayout()
        self.header_title = QLabel(T['title'])
        self.header_title.setFont(QFont("Segoe UI", 14, QFont.Weight.Bold))
        self.header_title.setStyleSheet("border: none; color: white; background: transparent;")
        
        btn_help = QPushButton("?")
        btn_help.setFixedSize(32, 32)
        btn_help.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_help.setStyleSheet(self.bw_btn_style(radius=16, font_size=14))
        btn_help.clicked.connect(self.show_help)
        
        btn_close = QPushButton("✕")
        btn_close.setFixedSize(32, 32)
        btn_close.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        btn_close.setStyleSheet(self.bw_btn_style(radius=16, font_size=12))
        btn_close.clicked.connect(self.close_app)
        
        header_layout.addWidget(self.header_title)
        header_layout.addStretch()
        header_layout.addWidget(btn_help)
        header_layout.addSpacing(5)
        header_layout.addWidget(btn_close)
        layout.addLayout(header_layout)
        
        layout.addSpacing(15)

        settings_layout = QHBoxLayout()
        self.label_count = QLabel(T['count'])
        self.label_count.setFont(QFont("Segoe UI", 11))
        self.label_count.setStyleSheet("border: none; color: white; background: transparent;")
        
        self.spin_count = QSpinBox()
        self.spin_count.setRange(1, 1000)
        self.spin_count.setValue(100)
        self.spin_count.setFixedHeight(35)
        self.spin_count.setStyleSheet("""
            QSpinBox { border: 2px solid white; border-radius: 8px; padding: 5px; font-size: 14px; background: black; color: white; }
            QSpinBox::up-button, QSpinBox::down-button { width: 0px; }
        """)
        
        self.btn_unlimited = QPushButton(T['unlim'])
        self.btn_unlimited.setFixedSize(110, 35)
        self.btn_unlimited.setCheckable(True)
        self.btn_unlimited.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_unlimited.setStyleSheet(self.bw_btn_style(radius=8, font_size=11, checkable=True))
        self.btn_unlimited.clicked.connect(self.toggle_unlimited)

        settings_layout.addWidget(self.label_count)
        settings_layout.addWidget(self.spin_count)
        settings_layout.addWidget(self.btn_unlimited)
        layout.addLayout(settings_layout)

        folder_layout = QHBoxLayout()
        self.btn_folder = QPushButton(T['folder'])
        self.btn_folder.setFixedHeight(35)
        self.btn_folder.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_folder.setStyleSheet(self.bw_btn_style(radius=8, font_size=11))
        self.btn_folder.clicked.connect(self.select_folder)
        
        self.label_folder = QLabel(T['folder_lbl'].format("Desktop"))
        self.label_folder.setFont(QFont("Segoe UI", 9))
        self.label_folder.setStyleSheet("border: none; color: white; background: transparent;")
        self.label_folder.setWordWrap(True)

        folder_layout.addWidget(self.btn_folder)
        folder_layout.addWidget(self.label_folder)
        layout.addLayout(folder_layout)

        layout.addSpacing(15)
        
        self.label_status = QLabel(T['ready'])
        self.label_status.setFont(QFont("Segoe UI", 11, QFont.Weight.Bold))
        self.label_status.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.label_status.setStyleSheet("border: none; color: white; background: transparent;")
        layout.addWidget(self.label_status)

        layout.addStretch()

        self.btn_generate = QPushButton(T['start'])
        self.btn_generate.setFixedHeight(45)
        self.btn_generate.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_generate.setStyleSheet(self.bw_btn_style(radius=15, font_size=14))
        self.btn_generate.clicked.connect(self.toggle_generation)
        layout.addWidget(self.btn_generate)

        layout.addSpacing(10)
        
        self.btn_epic = QPushButton(T['epic'])
        self.btn_epic.setFixedHeight(35)
        self.btn_epic.setCursor(QCursor(Qt.CursorShape.PointingHandCursor))
        self.btn_epic.setStyleSheet(self.bw_btn_style(radius=10, font_size=12))
        self.btn_epic.clicked.connect(lambda: webbrowser.open("https://www.epicgames.com/redeem"))
        layout.addWidget(self.btn_epic)
        
        self.stack.addWidget(self.page_main)

    def show_help(self):
        msg = QMessageBox(self)
        msg.setWindowTitle(TRANSLATIONS[self.lang]['help_title'])
        msg.setText(TRANSLATIONS[self.lang]['help_text'])
        msg.setStyleSheet("""
            QMessageBox { background-color: black; border: 1px solid white; } 
            QLabel { color: white; font-size: 13px; } 
            QPushButton { background: black; color: white; border: 1px solid white; padding: 5px 20px; border-radius: 5px; min-width: 60px;}
            QPushButton:hover { background: #333333; }
        """)
        msg.exec()

    def toggle_unlimited(self, checked):
        if checked:
            self.spin_count.setMaximum(2147483647) # Максимум при снятии лимита
        else:
            self.spin_count.setMaximum(1000) # Обычный лимит

    def select_folder(self):
        folder = QFileDialog.getExistingDirectory(self, TRANSLATIONS[self.lang]['folder'])
        if folder:
            self.save_folder = folder
            self.label_folder.setText(TRANSLATIONS[self.lang]['folder_lbl'].format(self.save_folder))

    def toggle_generation(self):
        T = TRANSLATIONS[self.lang]
        if self.generator_thread is not None and self.generator_thread.isRunning():
            self.generator_thread.is_running = False
            self.btn_generate.setText("...")
            self.btn_generate.setEnabled(False)
        else:
            # Считываем точное число из поля ввода
            count = self.spin_count.value()
            
            self.btn_generate.setText(T['stop'])
            self.btn_generate.setStyleSheet(self.bw_btn_style(radius=15, font_size=14).replace("background: black;", "background: white; color: black;"))
            self.label_status.setText(T['generating'])
            
            # Запускаем генератор строго с этим числом
            self.generator_thread = GeneratorThread(count, self.save_folder)
            self.generator_thread.progress.connect(self.update_progress)
            self.generator_thread.finished.connect(self.generation_finished)
            self.generator_thread.start()

    def update_progress(self, generated):
        self.label_status.setText(TRANSLATIONS[self.lang]['generated_prog'].format(generated))

    def generation_finished(self, generated_count, path):
        T = TRANSLATIONS[self.lang]
        self.label_status.setText(T['generated_done'].format(generated_count, path))
        self.btn_generate.setEnabled(True)
        self.btn_generate.setText(T['start'])
        self.btn_generate.setStyleSheet(self.bw_btn_style(radius=15, font_size=14))

    def close_app(self):
        if self.generator_thread and self.generator_thread.isRunning():
            self.generator_thread.is_running = False
            self.generator_thread.wait()
        sys.exit()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton: self.old_pos = event.globalPosition().toPoint()
    def mouseMoveEvent(self, event):
        if self.old_pos is not None:
            delta = QPoint(event.globalPosition().toPoint() - self.old_pos)
            self.move(self.x() + delta.x(), self.y() + delta.y())
            self.old_pos = event.globalPosition().toPoint()
    def mouseReleaseEvent(self, event): self.old_pos = None

if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())
